# scripts/config.py

# Your Project URL
SUPABASE_URL = "https://dlynitjoedsdrljotzyz.supabase.co"

# Your SERVICE ROLE Key (The "God Mode" key starting with eyJ...)
# DO NOT share this key with anyone!
SUPABASE_SERVICE_KEY = "sb_secret_vvFE7QZj_fKY2ekwUJ4KSQ_59J_bKuY"