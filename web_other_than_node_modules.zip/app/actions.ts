'use server'

import { createClient } from '@supabase/supabase-js'
import { redirect } from 'next/navigation'

// --- 1. SETUP CLIENT WITH NO CACHING ---
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  {
    auth: { persistSession: false },
    global: { headers: { 'Cache-Control': 'no-store' } } // <--- CRITICAL FIX
  }
)

// --- HELPER: Pick a "Star" Player ---
async function getRandomStarPlayerId() {
  console.log("Searching for a star player...")

  // 1. Pick players with a rating > 50 (Our injected stars are 99)
  const { data: stars, error } = await supabase
    .from('players')
    .select('id')
    .gt('rating', 50)

  // 2. Fallback: If no stars found (data issue), pick any random player
  if (error || !stars || stars.length === 0) {
    console.log("No stars found. Falling back to random ID 1-200.")
    return Math.floor(Math.random() * 200) + 1
  }

  // 3. Pick Random from the Star list
  const randomIndex = Math.floor(Math.random() * stars.length)
  console.log(`Found ${stars.length} stars. Picking index ${randomIndex}`)
  return stars[randomIndex].id
}

// --- LOBBY ACTIONS ---

export async function createRoom(formData: FormData) {
  const username = formData.get('username') as string
  const code = Math.random().toString(36).substring(2, 6).toUpperCase()

  const { data: room, error } = await supabase
    .from('rooms')
    .insert({ code, status: 'WAITING' })
    .select()
    .single()

  if (error) throw new Error(error.message)

  await supabase.from('participants').insert({ room_id: room.id, username, is_host: true })
  redirect(`/room/${code}?username=${encodeURIComponent(username)}`)
}

export async function joinRoom(formData: FormData) {
  const username = formData.get('username') as string
  const code = (formData.get('code') as string).toUpperCase()

  const { data: room } = await supabase.from('rooms').select('id').eq('code', code).single()

  if (!room) return redirect('/?error=room_not_found')

  const { error } = await supabase
    .from('participants')
    .insert({ room_id: room.id, username, is_host: false })

  if (error && error.code !== '23505') throw new Error(error.message)

  redirect(`/room/${code}?username=${encodeURIComponent(username)}`)
}

// --- GAME ACTIONS ---

export async function startGame(roomId: string) {
  console.log("STARTING GAME for Room:", roomId)
  const randomId = await getRandomStarPlayerId()
  
  await supabase
    .from('rooms')
    .update({ 
      status: 'PLAYING', 
      current_round: 1, 
      current_player_id: randomId 
    })
    .eq('id', roomId)
}

export async function nextRound(roomId: string, currentRound: number) {
  console.log("NEXT ROUND called. Current:", currentRound)

  if (currentRound >= 10) {
    await supabase.from('rooms').update({ status: 'FINISHED' }).eq('id', roomId)
    return
  }

  const randomId = await getRandomStarPlayerId()
  console.log("Next Player ID:", randomId)

  await supabase
    .from('rooms')
    .update({ 
      current_round: currentRound + 1, 
      current_player_id: randomId 
    })
    .eq('id', roomId)
}